-- MySQL dump 10.13  Distrib 5.6.24, for osx10.8 (x86_64)
--
-- Host: 127.0.0.1    Database: classroutine
-- ------------------------------------------------------
-- Server version	5.7.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `exam_committee`
--

DROP TABLE IF EXISTS `exam_committee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exam_committee` (
  `exam_committee_id` int(11) NOT NULL AUTO_INCREMENT,
  `exam_id` bigint(20) NOT NULL,
  `session` int(11) NOT NULL,
  `semester` int(11) NOT NULL,
  `chairman_id` int(11) NOT NULL,
  `start_Date` varchar(30) NOT NULL,
  `end_date` varchar(30) NOT NULL,
  PRIMARY KEY (`exam_committee_id`),
  UNIQUE KEY `exam_committee_unique` (`exam_id`,`session`),
  CONSTRAINT `exam_exam_committee_fk` FOREIGN KEY (`exam_id`) REFERENCES `exam` (`exam_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam_committee`
--

LOCK TABLES `exam_committee` WRITE;
/*!40000 ALTER TABLE `exam_committee` DISABLE KEYS */;
INSERT INTO `exam_committee` VALUES (1,1,2011,41,1,'2015-08-12','2016-02-15'),(2,1,2012,31,0,'2015-08-20','2016-02-20'),(3,1,2013,21,1,'2015-08-12','2016-02-03'),(4,1,2014,11,0,'2015-08015','2016-02-06'),(5,2,2011,41,2,'2015-8-13','2016-02-15'),(6,2,2012,31,3,'2015-08-10','2016-02-20'),(7,2,2013,21,2,'2015-08-13','2016-03-03'),(8,2,2014,11,3,'2015-09-01','2016-03-01');
/*!40000 ALTER TABLE `exam_committee` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-07 19:30:56
