-- MySQL dump 10.13  Distrib 5.6.24, for osx10.8 (x86_64)
--
-- Host: 127.0.0.1    Database: classroutine
-- ------------------------------------------------------
-- Server version	5.7.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course` (
  `course_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_code` varchar(30) NOT NULL,
  `course_title` varchar(30) NOT NULL,
  `semester` int(11) NOT NULL,
  `session` int(11) NOT NULL,
  `offering_dept` varchar(30) NOT NULL,
  `accepting_dept` varchar(30) NOT NULL,
  `general_type_id` int(11) NOT NULL,
  `credit` decimal(2,1) NOT NULL,
  `hour` int(11) DEFAULT NULL,
  PRIMARY KEY (`course_id`),
  UNIQUE KEY `course_unique` (`course_code`,`offering_dept`,`accepting_dept`,`session`,`course_title`),
  KEY `general_type_course_fk1` (`general_type_id`) USING BTREE,
  CONSTRAINT `general_type_course_fk` FOREIGN KEY (`general_type_id`) REFERENCES `general_type` (`general_type_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COMMENT='Contains course information';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES (1,'CSE-401','Machine Learning',41,2011,'CSE','CSE',1,3.0,0),(2,'CSE-402','Machine Learning Lab',41,2011,'CSE','CSE',2,2.0,2),(3,'CSE-101','Structured Programming Languag',11,2014,'CSE','CSE',1,3.0,2),(4,'CSE-102','Structured Programming Languag',11,2014,'CSE','CSE',2,3.0,0),(5,'CSE-201','Algorithm ',21,2013,'CSE','CSE',1,3.0,0),(6,'EEE-121','Electrical Circuits ',11,2014,'EEE','EEE',1,3.0,3),(7,'MAT-103K','Differential & Integral Calcul',11,2014,'MATH','EEE',1,3.0,3),(8,'EEE-221','Electronics',21,2013,'EEE','EEE',1,3.0,3),(9,'EEE-323','Digital Electronics',31,2012,'EEE','EEE',1,3.0,3),(10,'EEE-324','Digital Electronics Lab',31,2012,'EEE','EEE',1,1.5,3),(11,'EEE-421','Solid State Devices',41,2011,'EEE','EEE',1,3.0,6);
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-07 19:30:55
